-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 21, 2023 at 10:14 AM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `house_rental_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(30) NOT NULL,
  `name` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`) VALUES
(5, 'Bachelor Apartment Boys '),
(6, 'Bachelor Apartment Girls ');

-- --------------------------------------------------------

--
-- Table structure for table `houses`
--

CREATE TABLE `houses` (
  `id` int(30) NOT NULL,
  `house_no` varchar(50) NOT NULL,
  `category_id` int(30) NOT NULL,
  `description` text NOT NULL,
  `price` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `houses`
--

INSERT INTO `houses` (`id`, `house_no`, `category_id`, `description`, `price`) VALUES
(2, '1a', 5, 'Bedroom\r\nBathroom\r\nKitchen \r\nBed\r\nWardrobe', 4248),
(3, '1b', 5, 'Bedroom\r\nBathroom\r\nKitchen\r\nWardrobe', 4248),
(4, '1c', 5, 'Bedroom\r\nBathroom\r\nKitchen\r\nWardrobe', 4248),
(6, '1d', 5, 'Bedroom\r\nBathroom\r\nKitchen\r\nWardrobe', 4248),
(7, '2a', 5, 'Bedroom\r\nBathroom\r\nKitchen\r\nWardrobe', 4248),
(8, '2b', 5, 'Bedroom\r\nBathroom\r\nKitchen\r\nWardrobe', 4248),
(9, '2c', 5, 'Bedroom\r\nBathroom\r\nKitchen\r\nWardrobe', 4248),
(10, '2d', 5, 'Bedroom\r\nBathroom\r\nKitchen\r\nWardrobe', 4248),
(11, '3a', 5, 'Bedroom\r\nBathroom\r\nKitchen\r\nWardrobe', 4248),
(12, '3b', 5, 'Bedroom\r\nBathroom\r\nKitchen\r\nWardrobe', 4248),
(13, '3c', 5, 'Bedroom\r\nBathroom\r\nKitchen\r\nWardrobe', 4248),
(14, '3d', 5, 'Bedroom\r\nBathroom\r\nKitchen\r\nWardrobe', 4248),
(15, '4a ', 5, 'Bedroom\r\nBathroom\r\nKitchen\r\nWardrobe', 4248),
(16, '4b', 5, 'Bedroom\r\nBathroom\r\nKitchen\r\nWardrobe', 4248),
(17, '4c', 5, 'Bedroom\r\nBathroom\r\nKitchen\r\nWardrobe', 4248),
(18, '4d', 5, 'Bedroom\r\nBathroom\r\nKitchen\r\nWardrobe', 4248),
(19, '5a', 5, 'Bedroom\r\nBathroom\r\nKitchen\r\nWardrobe', 4248),
(20, '5b', 5, 'Bedroom\r\nBathroom\r\nKitchen\r\nWardrobe', 4248),
(21, '5c', 5, 'Bedroom\r\nBathroom\r\nKitchen\r\nWardrobe', 4248),
(22, '5d', 5, 'Bedroom\r\nBathroom\r\nKitchen\r\nWardrobe', 4248),
(23, '6a', 5, 'Bedroom\r\nBathroom\r\nKitchen\r\nWardrobe', 4248),
(24, '6b', 5, 'Bedroom\r\nBathroom\r\nKitchen\r\nWardrobe', 4248),
(25, '7a', 5, 'Bedroom\r\nBathroom\r\nKitchen\r\nWardrobe', 4248),
(26, '7b', 5, 'Bedroom\r\nBathroom\r\nKitchen\r\nWardrobe', 4248),
(27, '1aa', 6, 'Bedroom\r\nBathroom\r\nKitchen\r\nWardrobe', 4248),
(28, '1bb', 6, 'Bedroom\r\nBathroom\r\nKitchen\r\nWardrobe\r\nWifi', 4248),
(29, '1cc', 6, 'Bedroom\r\nBathroom\r\nKitchen\r\nWardrobe\r\nWifi', 4248),
(30, '1dd', 6, 'Bedroom\r\nBathroom\r\nKitchen\r\nWardrobe\r\nWifi', 4248),
(31, '2aa', 6, 'Bedroom\r\nBathroom\r\nKitchen\r\nWardrobe\r\nWifi', 4248),
(32, '2bb', 6, 'Bedroom\r\nBathroom\r\nKitchen\r\nWardrobe\r\nWifi', 4248),
(33, '2cc', 6, 'Bedroom\r\nBathroom\r\nKitchen\r\nWardrobe\r\nWifi', 4248),
(34, '2dd', 6, 'Bedroom\r\nBathroom\r\nKitchen\r\nWardrobe\r\nWifi', 4248),
(35, '3aa', 6, 'Bedroom\r\nBathroom\r\nKitchen\r\nWardrobe\r\nWifi', 4248),
(36, '3dd', 6, 'Bedroom\r\nBathroom\r\nKitchen\r\nWardrobe\r\nWifi', 4248),
(37, '3cc', 6, 'Bedroom\r\nBathroom\r\nKitchen\r\nWardrobe\r\nWifi', 4248),
(38, '4aa', 6, 'Bedroom\r\nBathroom\r\nKitchen\r\nWardrobe\r\nWifi', 4248),
(39, '4bb', 6, 'Bedroom\r\nBathroom\r\nKitchen\r\nWardrobe\r\nWifi', 4248),
(40, '4cc', 6, 'Bedroom\r\nBathroom\r\nKitchen\r\nWardrobe\r\nWifi', 4248),
(41, '4dd', 6, 'Bedroom\r\nBathroom\r\nKitchen\r\nWardrobe\r\nWifi', 4248),
(42, '5aa', 6, 'Bedroom\r\nBathroom\r\nKitchen\r\nWardrobe\r\nWifi', 4248),
(43, '5bb', 6, 'Bedroom\r\nBathroom\r\nKitchen\r\nWardrobe\r\nWifi', 4248),
(44, '5cc', 6, 'Bedroom\r\nBathroom\r\nKitchen\r\nWardrobe\r\nWifi', 4248),
(45, '5dd', 6, 'Bedroom\r\nBathroom\r\nKitchen\r\nWardrobe\r\nWifi', 4248),
(46, '6aa', 6, 'Bedroom\r\nBathroom\r\nKitchen\r\nWardrobe\r\nWifi', 4248),
(47, '6bb', 6, 'Bedroom\r\nBathroom\r\nKitchen\r\nWardrobe\r\nWifi', 4248),
(48, '7aa', 6, 'Bedroom\r\nBathroom\r\nKitchen\r\nWardrobe\r\nWifi', 4248),
(49, '7bb', 6, 'Bedroom\r\nBathroom\r\nKitchen\r\nWardrobe\r\nWifi', 4248);

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `id` int(30) NOT NULL,
  `tenant_id` int(30) NOT NULL,
  `amount` float NOT NULL,
  `invoice` varchar(50) NOT NULL,
  `date_created` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`id`, `tenant_id`, `amount`, `invoice`, `date_created`) VALUES
(1, 2, 2500, '123456', '2020-10-26 11:29:35'),
(2, 2, 7500, '136654', '2020-10-26 11:30:21');

-- --------------------------------------------------------

--
-- Table structure for table `system_settings`
--

CREATE TABLE `system_settings` (
  `id` int(30) NOT NULL,
  `name` text NOT NULL,
  `email` varchar(200) NOT NULL,
  `contact` varchar(20) NOT NULL,
  `cover_img` text NOT NULL,
  `about_content` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `system_settings`
--

INSERT INTO `system_settings` (`id`, `name`, `email`, `contact`, `cover_img`, `about_content`) VALUES
(1, 'House Rental Management System', 'info@sample.comm', '+6948 8542 623', '1603344720_1602738120_pngtree-purple-hd-business-banner-image_5493.jpg', '&lt;p style=&quot;text-align: center; background: transparent; position: relative;&quot;&gt;&lt;span style=&quot;color: rgb(0, 0, 0); font-family: &amp;quot;Open Sans&amp;quot;, Arial, sans-serif; font-weight: 400; text-align: justify;&quot;&gt;&amp;nbsp;is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&rsquo;s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.&lt;/span&gt;&lt;br&gt;&lt;/p&gt;&lt;p style=&quot;text-align: center; background: transparent; position: relative;&quot;&gt;&lt;br&gt;&lt;/p&gt;&lt;p style=&quot;text-align: center; background: transparent; position: relative;&quot;&gt;&lt;br&gt;&lt;/p&gt;&lt;p&gt;&lt;/p&gt;');

-- --------------------------------------------------------

--
-- Table structure for table `tenants`
--

CREATE TABLE `tenants` (
  `id` int(30) NOT NULL,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `contact` varchar(50) NOT NULL,
  `house_id` int(30) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '1 = active, 0= inactive',
  `date_in` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tenants`
--

INSERT INTO `tenants` (`id`, `firstname`, `middlename`, `lastname`, `email`, `contact`, `house_id`, `status`, `date_in`) VALUES
(3, 'Jaqueen ', 'Mokhoma', 'Teffu ', '218586244@tut4life.ac.za', '0793095966', 2, 0, '2023-02-02'),
(4, 'Jaqueen ', 'Mokhoma', 'Teffu ', '218586244@tut4life.ac.za', '0793095966', 25, 1, '2023-02-02');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(30) NOT NULL,
  `name` text NOT NULL,
  `username` varchar(200) NOT NULL,
  `password` text NOT NULL,
  `type` tinyint(1) NOT NULL DEFAULT 2 COMMENT '1=Admin,2=Staff'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `username`, `password`, `type`) VALUES
(1, 'Administrator', 'admin', '0192023a7bbd73250516f069df18b500', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `houses`
--
ALTER TABLE `houses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `system_settings`
--
ALTER TABLE `system_settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tenants`
--
ALTER TABLE `tenants`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `houses`
--
ALTER TABLE `houses`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `system_settings`
--
ALTER TABLE `system_settings`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tenants`
--
ALTER TABLE `tenants`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
